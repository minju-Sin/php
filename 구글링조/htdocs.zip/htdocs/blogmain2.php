<?php 
session_start();

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

mysqli_query($connect, "set session character_set_connection=utf8;");       
mysqli_query($connect, "set session character_set_results=utf8;");
mysqli_query($connect, "set session character_set_client=utf8;");   

$profileimg=$_SESSION['nickname'];
?>
<!DOCTYPE html>
<html lang="ko">
<form method="post" action="blogmain2.php"></form>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BlogMain</title>
    <link rel="stylesheet" href="blogmain2.css">
</head>
<body>
    <br><br>
    <div class="main">
        <div>
            <button id="logo" onclick="location.href='blogmain2.php'"></button>
            <form method="get" action="search.php" style="display:inline;">
            <input type="text" placeholder="검색어 입력" id="search" name="search">
            <input type="submit" id="searchicon" value="" name="category1"> 
            </form>
            <input type="button" value="<?php echo "{$_SESSION['nickname']}"; ?>" id="profile"
			onclick = "location.href = 'profile.php'">
            <img src="./img/<?php echo $profileimg ?>"
				onerror="this.src='./img/profileimg.jpg'" class="myimg">
        </div>
        <br><hr>
        <div style="height: 30px; margin-top: 20px; font-size: 20px;">
            <span>추천 블로그</span>
            <span style="float: right; margin-right: 145px;">내 블로그</span>
        </div>
        <?php
            $sqll = "select *from post order by rand()";                      // 테이블 랜덤으로 검색 
            $resultt = mysqli_query ($connect, $sqll);          // 질의 수행
            $totall = mysqli_num_fields ($resultt);             // 필드의 개수 구하기
        ?>
    
    <div class="blogall">
        <?php
      $cn=1;
                while($rowss = mysqli_fetch_assoc($resultt)){
                    if($rowss['NICKNAME']!=$_SESSION['nickname']&& $cn<4){
						$imgname=$rowss['NUM'].$rowss['NICKNAME'];
                  ?>
                          <div class="blog<?php echo $cn?>">
						  <img src="./img/<?php echo $imgname ?>" style="width:230px; height:300px;"
							onerror="this.src='./img/sample.png'">
                            <p>
							<a href = "view.php?number=<?php echo $rowss['NUM']?>"
							style="text-decoration:none; color:black; background-color:white;">
							<?php echo $rowss['TITLE']?></p></a>
                          </div>
        <?php
            $cn++;
                }
            }
        ?>

            <div class="myprofile">
                <br>
                <img src="./img/<?php echo $profileimg ?>"
				onerror="this.src='./img/profileimg.jpg'" id="mp1">
                <p id="mp2"><?php echo "{$_SESSION['nickname']}"; ?></p>
                <input type="button" value="로그아웃" id="mp3" onclick = "location.href = 'logout.php'">
                <br><br>
                <input type="button" value="글쓰기" id="mp4" onclick = "location.href = 'webpost1.php'"><br>
				<form method="get" action="blogmain.php" style="display:inline;">
                <input type="submit" value="<?php echo "내 블로그"; ?>" id="mp4" name="blognum">    
				</form>
				<input type="button" value="프로필 편집" id="mp4" onclick = "location.href = 'profile.php'">
			</div>
        </div>
        <!-- 이웃 게시글 -->
        <?php
            $sql = "select *from post order by rand()";                      // 테이블 랜덤으로 검색 
            $result = mysqli_query ($connect, $sql);          // 질의 수행
            $total = mysqli_num_fields ($result);             // 필드의 개수 구하기
        ?>
        <div class="newpost">
            <span>이웃 새글</span>
        </div>
        <div style="width:1000px;">
        <?php
                while($rows = mysqli_fetch_assoc($result)){ //DB에 저장된 데이터 수 (열 기준) 
                     if($rows['NICKNAME']!=$_SESSION['nickname']){
						 $imgname=$rows['NUM'].$rows['NICKNAME'];
                  ?>
                         <div class="new1">
						 
						 <img src="./img/<?php echo $imgname ?>"
							onerror="this.src='./img/sample.png'" class="new1-2">
							<?php $profileimg2=$rows['NICKNAME']; ?>
                            <img src="./img/<?php echo $profileimg2 ?>"
								onerror="this.src='./img/profileimg.jpg'" class="new1-1">
							<form method="get" action="blogmain.php" style="display:inline;">
                            <input type="submit" id="newfont1" value="<?php echo $rows['NICKNAME']?>" name="blognum">
							</form>
                            <p id="title"><a href = "view.php?number=<?php echo $rows['NUM']?>"
							style="text-decoration:none; color:black;">
							<?php echo $rows['TITLE']?></a></p>
							<p>조회수: <?php echo $rows['HIT']?></p>
                        </div>
        <?php
                }
            }
        ?>
            <br>
        </div>
    </div>
</body>
</html>