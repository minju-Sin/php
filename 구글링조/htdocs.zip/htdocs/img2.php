<?php 
session_start();


$tempFile = $_FILES['imgFile']['tmp_name'];
$fileTypeExt = explode("/", $_FILES['imgFile']['type']);
$fileType = $fileTypeExt[0];
$fileExt = $fileTypeExt[1];
$extStatus = false;

		switch($fileExt){
		case 'jpeg':
		case 'jpg':
		case 'gif':
		case 'bmp':
		case 'png':
			$extStatus = true;
			break;
	
		default:
			echo "<script>alert('이미지 파일을 업로드 해주세요!(jpg, bmp, gif, png)');history.back();</script>";
			break;
		}
     
		// 이미지 파일이 맞는지 검사. 
		if($fileType == 'image'){
			// 허용할 확장자를 jpg, bmp, gif, png로 정함, 그 외에는 업로드 불가
			if($extStatus){
				$imgnickname=$_SESSION['nickname'];
				$resFile = "./img/{$imgnickname}";
				// 임시 파일 옮길 디렉토리 및 파일명
				// 임시 저장된 파일을 우리가 저장할 디렉토리 및 파일명으로 옮김
				$imageUpload = move_uploaded_file($tempFile, $resFile);
				
				echo "<script>alert('프로필 사진이 변경되었습니다!');history.back();</script>";
				echo "<script>location.replace('profile.php');</script>";
			}	
			else {
				echo "<script>alert('파일 확장자는 jpg, bmp, gif, png 이어야 합니다');history.back();</script>";
			}	
		}	// end if - filetype
			// 파일 타입이 image가 아닌 경우 
		else {
			echo "<script>alert('이미지 파일이 아닙니다!');history.back();</script>";
		}
		?>