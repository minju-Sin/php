<?php 
session_start();

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

mysqli_query($connect, "set session character_set_connection=utf8;");       
mysqli_query($connect, "set session character_set_results=utf8;");
mysqli_query($connect, "set session character_set_client=utf8;");   


$blognum = $_GET['blognum'];
$profileimg=$_SESSION['nickname'];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>myblog</title>
    <link rel="stylesheet" href="blogmain.css">
</head>
<body>
</table>
    <br>
    <div class="main">
        <div>
            <button id="logo" onclick="location.href='blogmain2.php'"><img src = "./logo.png" width="200" height="50"></img></button>
            <input type="button" value=<?php echo "{$_SESSION['nickname']}"; ?> id="profile">
            <img src="./img/<?php echo $profileimg ?>"
								onerror="this.src='./img/profileimg.jpg'" class="myimg">
            <br><br><br>
			<?php 
			$sql = "select *from minformation";                    
			$result = mysqli_query ($connect, $sql);       
			$total = mysqli_num_fields ($result); 
			while($rows = mysqli_fetch_assoc($result)){
				if($blognum=="내 블로그"){ $profileimg2=$_SESSION['nickname'];}
				else if($blognum==$rows['NICKNAME']){ $profileimg2=$rows['NICKNAME'];}
			}
			?>
            <img src="./img/<?php echo $profileimg2 ?>"
								onerror="this.src='./img/profileimg.jpg'" class="userimg">
            <span id="blogtitle">
			<?php 
			$sql = "select *from minformation";                    
			$result = mysqli_query ($connect, $sql);       
			$total = mysqli_num_fields ($result); 
			
			while($rows = mysqli_fetch_assoc($result)){
			if($blognum=="내 블로그"){echo "{$_SESSION['nickname']}"; break;}
			else if($blognum==$rows['NICKNAME']){echo "{$rows['NICKNAME']}";}}
			?> 님의 블로그</span>
			<?php
			if($blognum=="내 블로그"|| $blognum==$_SESSION['nickname']){?>
			<input type="button" value="글쓰기" id="mp4" 
			onclick = "location.href = 'webpost1.php'" > <?php }?>
			<br><br>
            <hr>
        </div>
<?php
   $sql = "select *from post";                    
   $result = mysqli_query ($connect, $sql);       
   $total = mysqli_num_fields ($result);           
?>
<table align = "center">
        <thead align = "center">
        <tr>
        <td width = "500">제목</td>
        <td width = "150">작성자</td>
        <td width = "250">날짜</td>
        <td width = "50">조회수</td>
        </tr>
        </thead>

        <tbody align = "center">
        <?php
                while($rows = mysqli_fetch_assoc($result)){ //DB에 저장된 데이터 수 (열 기준)
                        if($total%2==0){
        ?>                      <tr class = "even">
                        <?php   }
                        else{
        ?>                      <tr>
                        <?php } ?>
                  <?php 
                     if($rows['NICKNAME']==$blognum||
					 ($rows['NICKNAME']==$_SESSION['nickname']&&
					 $blognum=="내 블로그")){ // 현재 로그인한 닉네임이 작성자일 경우에만 글 나오게 하기 
                  ?>
                <td>
                <a href = "view.php?number=<?php echo $rows['NUM']?>">
                <?php echo $rows['TITLE']?></td>
                  <td><?php echo $rows['NICKNAME']?></td>
                <td><?php echo $rows['DATE']?></td>
                <td><?php echo $rows['HIT']?></td>
                </tr>
        <?php
                $total--;
                }
            }
        ?>
        </tbody>
</table>
    </div>

</body>
</html>