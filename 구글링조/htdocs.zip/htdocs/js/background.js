//배경화면 만들기
const images = [
    "img/0.jpg",
    "img/1.jpg",
    "img/2.jpg"
];

//랜덤 사용 
const chosenImage = images[Math.floor(Math.random() * images.length)];

const body = document.getElementsByTagName('body');
body[0].background = `${chosenImage}`;
/*
//javascript로 html만들기 
const bgimage = document.createElement("img");

bgimage.src = `img/${chosenImage}`;

document.body.appendChild(bgimage);
*/
