//시계
//매 초 마다 일어나게 만드는 것이 interval
//setInterval은 두개의 변수를 받음 첫번째 변수는 실행하고자 하는 function 
//두 번째 변수는 호출되는 함수의 간격을 몇 ms으로 할지 적음 
//이것은 sayHello 함수를 5초마다 실행하는 것 
//setInterval(함수이름, 5000);

//몇 초 뒤에 보여주는 것 timeout (한번만 됨)
//setTimeout(함수이름, 5000);

//길이가 1인 문자를 두개의 문자로 바꾸는데 padStart필요 <-> padEnd는 문자열 뒤에 추가하는 것 
//"문자".padStart(2,"0") ==> 문자를 입력했을때 문자의 길이가 2가 아닐때 문자 앞에 0을 추가한다. 


const clock = document.querySelector("h2#clock");

function getClock(){
    const date = new Date(); //시간 
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0"); 
    
    clock.innerText= `${hours}:${minutes}:${seconds}`; 
}
getClock();
setInterval(getClock, 1000);
