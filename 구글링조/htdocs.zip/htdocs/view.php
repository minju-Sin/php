<?php 
session_start();

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

mysqli_query($connect, "set session character_set_connection=utf8;");		 
mysqli_query($connect, "set session character_set_results=utf8;");
mysqli_query($connect, "set session character_set_client=utf8;");	
?>
<!-- 게시글 읽기 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>post_coment</title>
</head>
<style>
    #logo{
    vertical-align: middle;
    border: none;
    background: none;
    margin-bottom: 5px;
    width: 200px;
    height: 50px;
    background-size: cover;
    cursor: pointer;
}
.main{
    width: 1000px;
    margin: auto;
}
#blogtitle{
    font-size: 20px;
    vertical-align: middle;
	background:none;
	border:none;
    background-color: rgb(219, 230, 173);
    cursor: pointer;
	height:28px;
}
.myimg{
    width: 40px;
    height: 40px;
    border-radius: 100%;
    float: right;
}
#profile{
    float: right;
    margin-top: 10px;
    border: none;
    background-color: none;
}
#mp1, #mp2, #mp3{
    float: right;
}
#mp2{
    margin-right: 10px;
}
#contents{
    resize: none;
    width: 1000px;
    height: 100px;
    font-size: 15px;
    border-color: rgb(136, 136, 136);
}
#name{
    resize: none;
    width: 100px;
    height: 20px;
    font-size: 15px;
    border-color: rgb(136, 136, 136);
}
#c{
	background:none;
	border:none;
	font-size:18px;
	cursor:pointer;
}
</style>
<body>
    <?php
    $connect = mysqli_connect('127.0.0.1', 'root', '202130', 'webblog');
    $number = $_GET['number'];  // GET 방식 사용
    $query = "select TITLE, CONTENT, DATE, HIT, NICKNAME from post where NUM = $number";
    $result = $connect->query($query);
	// 조회수
	$hit = "update post set HIT=HIT+1 where NUM=$number";
	$connect->query($hit);
    $rows = mysqli_fetch_assoc($result);
	$_SESSION['checknum']=$number;

	$imgname=$number.$rows['NICKNAME'];
	$profileimg=$_SESSION['nickname'];
    ?>
    <br>
    <div class="main">
        <div>
            <button id="logo" onclick="location.href='blogmain2.php'"><img src = "./logo.png" width="200" height="50"></img></button>
            <input type="button" value=<?php echo "{$_SESSION['nickname']}"; ?> id="profile">
            <img src="./img/<?php echo $profileimg ?>"
								onerror="this.src='./img/profileimg.jpg'" alt="My Image" class="myimg">
            <br><br><br>
			<form method="get" action="blogmain.php" style="display:inline;">
            <input type="submit" id="blogtitle" value="<?php echo $rows['NICKNAME']; ?>" name="blognum"><span id="blogtitle">님의 블로그</span>
			</form>
            <input type="button" value="목록" id="mp1" 
			onclick="location.href='blogmain.php?blognum=<?php echo $rows['NICKNAME']; ?>'">
            <br><br>
            <hr>
        </div>
        <!-- 글읽기 -->
        <table>
			<tr>
				<td style="font-size:20px;"><?php echo $rows['DATE'] ?></td>
            </tr>
            <tr>
                <td colspan="2" style="font-size: 30px;font-weight: bold;"><?php echo $rows['TITLE'] ?></td> 
            </tr>   
			<tr>
				<td colspan="2">
					<img src="./img/<?php echo $imgname ?>" style="max-width:1000px"
					onerror="this.style.display='none'">
				</td>
			</tr>
            <tr>
                <td style="font-size: 20px;" colspan="2"><br>
					<?php echo $rows['CONTENT']=nl2br($rows['CONTENT']); ?>
                </td>
            </tr>
			<tr>
				<td ><br><?php echo $rows['NICKNAME'] ?></td>
				<td><br>조회수: <?php echo $rows['HIT'];?></td>
			</tr>
        </table>
        
        <hr>
        <br><h2>댓글 목록</h2>
        <!-- 댓글 -->
        <table>
                <!-- 댓글읽기 -->
            <?php
                $sql1 = "select *from coment";                      // 테이블 검색 질의
                $result1 = mysqli_query ($connect, $sql1);          // 질의 수행
                $total1 = mysqli_num_fields ($result1);             // 필드의 개수 구하기
            ?>
            <?php
                while($rows = mysqli_fetch_assoc($result1)){ //DB에 저장된 데이터 수 (열 기준)
                        if($total1%2==0){
        ?>                      <tr class = "even">
                        <?php   }
                        else{
        ?>                      <tr>
                        <?php } ?>
						<?php 
							if($rows['CHECKNUM']==$number){
						?>
				<form method="get" action="blogmain.php" style="display:inline;">		
                <td width = "150">
				<input type="submit" value="<?php echo $rows['NICKNAME']?>" name="blognum" id="c">
				</td>
				</form>
                <td width = "700"><?php echo $rows['CONTENT']?>
                <td width = "150"><?php echo $rows['DATE']?></td>
                </tr>
        <?php
                }
			}
        ?>
        </table>
        <table>
            <tr>
                <td>
                <br>
					<form action ="./content.php" method = "post">
                    <br><textarea value="내용" id="contents" name="content" placeholder="댓글을 입력하세요(최대100글자)"></textarea>
                </td>
            </tr>
            <tr>
                <td><input type="submit" value="작성하기" id="mp3"></td>
				</form>
            </tr>
        </table>
    </div>
</body>
</html>