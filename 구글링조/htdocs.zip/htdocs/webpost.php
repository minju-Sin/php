<?php
session_start();
   $connect = mysqli_connect ('localhost', 'root', '202130');   
   mysqli_select_db ($connect, 'webblog');          // 질의 수행

   /* ---------- 한글 깨짐 방지 코드 -----------------*/ 
   
   mysqli_query($connect, "set session character_set_connection=utf8;");       
   mysqli_query($connect, "set session character_set_results=utf8;");       
   mysqli_query($connect, "set session character_set_client=utf8;");   
    $title = $_POST['title'];
    $content = $_POST['content'];
    $nickname = $_SESSION['nickname'];
    $date = date('Y-m-d');
	$tempFile = $_FILES['imgFile']['tmp_name'];

    if($title && $content){
        $sql = "INSERT INTO post(NUM, TITLE, CONTENT, NICKNAME, DATE, HIT)

        VALUES(0, '{$_POST['title']}', '{$_POST['content']}', '$nickname', '$date', 0)";

		if (mysqli_query($connect, $sql)) {
				echo "<script>alert('게시글 작성에 성공하였습니다!')</script>";
				echo "<script>location.replace('blogmain.php?blognum={$_SESSION['nickname']}');</script>";
		}
		
		// 사진 업로드하기

		// 파일타입 및 확장자 체크
		$fileTypeExt = explode("/", $_FILES['imgFile']['type']);

		// 파일 타입 
		$fileType = $fileTypeExt[0];

		// 파일 확장자
		$fileExt = $fileTypeExt[1];

		// 확장자 검사
		$extStatus = false;

		switch($fileExt){
		case 'jpeg':
		case 'jpg':
		case 'gif':
		case 'bmp':
		case 'png':
			$extStatus = true;
			break;
	
		default:
			echo "<script>alert('이미지 파일을 업로드 해주세요!(jpg, bmp, gif, png)');history.back();</script>";
			break;
		}
     
		// 이미지 파일이 맞는지 검사. 
		if($fileType == 'image'){
			// 허용할 확장자를 jpg, bmp, gif, png로 정함, 그 외에는 업로드 불가
			if($extStatus){
				$postsql = "select *from post"; 
                $result1 = mysqli_query ($connect, $postsql);   
                $row1 = mysqli_num_rows ($result1);
				
				$counte=0;
				
				while($rows2 = mysqli_fetch_assoc($result1)){ 
					$counte++;
					if($counte==$row1){
						$counte=$rows2['NUM'];
					}   
				}
				
				$resFile = "./img/{$counte}{$nickname}";
				// 임시 파일 옮길 디렉토리 및 파일명
				// 임시 저장된 파일을 우리가 저장할 디렉토리 및 파일명으로 옮김
				$imageUpload = move_uploaded_file($tempFile, $resFile);
			}	
			else {
				echo "<script>alert('파일 확장자는 jpg, bmp, gif, png 이어야 합니다');history.back();</script>";
			}	
		}	// end if - filetype
			// 파일 타입이 image가 아닌 경우 
		else {
			echo "<script>alert('이미지 파일이 아닙니다!');history.back();</script>";
		}

		// 사진 업로드 끗
    }
    else{
		if($title==false){
			echo "<script>alert('제목을 입력해주세요!');history.back();</script>";
		}
		else{
			echo "<script>alert('내용을 작성해주세요!');history.back();</script>";
		}
	}
	
	
	
?>

