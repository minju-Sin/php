<?php 
session_start();

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

$profileimg=$_SESSION['nickname'];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POST</title>
    <style>
        #submit{
            width: 80px;
            height: 40px;
            float: right;
            background-color: white;
            border: none;
            text-align: center;
        }
        #submit:hover{
            background-color: #8a8d92;
            color:white;
        }
        #posttable{
            margin: auto;
        }
        #title{
            width: 1000px;
            margin: auto;      
            height: 50px;
            font-size: 40px;
            border: none;
            resize: none;
        }
        #contents{
            width: 1000px;
            height: 500px;
            font-size: 15px;
            border: none;
            resize: none;
        }
        .textcolor{
            margin: auto;
        }
        .textcolor input{
            width: 50px;
            border: none;
            background-color: white;
        }
        #main{
            width: 1000px;
            margin: auto;
        }
        .myimg{
            width: 40px;
            height: 40px;
            border-radius: 100%;
            float: right;
        }
        #profile{
            float: right;
            margin-top: 10px;
            border: none;
            background-color: none;
        }
    </style>
</head>
<body>
    <form action ="./webpost.php" method = "post" enctype="multipart/form-data">
	
    <br>
    <div id="main">
        <div>
            <img src="/logo.png" alt="logo" width="200" height="50" onclick = "location.href = 'blogmain2.php'">
            <input type="button" value="<?php echo "{$_SESSION['nickname']}"; ?>" id="profile">
            <img src="./img/<?php echo $profileimg ?>"
								onerror="this.src='./img/profileimg.jpg'" class="myimg" name="myimg">
        </div>
    <br><br>
        <div id="posttable">
            <div>
                <textarea value="내용" id="title" name="title"
                placeholder="제목"></textarea>
            </div>
			<form name="reqform" method="post" action="img2.php" enctype="multipart/form-data"> 

 <hr> <br>
 <input type="file" name="imgFile" /><br>

            <hr width="1000px"><br>
            
            <div>
                <textarea value="내용" id="contents" name="content"
                placeholder="내용"></textarea>
            </div>
            <br>
            <input type="submit" value="작성하기" id="submit"> 
        </div>
    </div>
</body>
</html>