<?php 
session_start();

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

mysqli_query($connect, "set session character_set_connection=utf8;");		 
mysqli_query($connect, "set session character_set_results=utf8;");
mysqli_query($connect, "set session character_set_client=utf8;");	

$imgname=$_SESSION['nickname'];


?>
<!-- 게시글 읽기 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>profile_change</title>
</head>
<style>
#logo{
    vertical-align: middle;
    border: none;
    background: none;
    margin-bottom: 5px;
    width: 200px;
    height: 50px;
    background-size: cover;
    cursor: pointer;
}
.main{
    width: 1000px;
    margin: auto;
}
.myimg{
    width: 40px;
    height: 40px;
    border-radius: 100%;
    float: right;
}
#profile{
    float: right;
    margin-top: 10px;
    border: none;
    background-color: none;
}
#logout{
    height: 20px;
    font-size: 10px;
    cursor: pointer;
	float:right;
}
</style>
<body>
    <br><br>
    <div class="main">
        <div>
            <button id="logo" onclick="location.href='blogmain2.php'">
			<img src = "./logo.png" width="200" height="50"></button>
            <input type="button" value=<?php echo "{$_SESSION['nickname']}"; ?> id="profile">
            <img src="./img/<?php echo $imgname ?>" onerror="this.src='./img/profileimg.jpg'" 
			class="myimg"><br>
			<input type="button" id="logout" value="로그아웃" onclick = "location.href = 'logout.php'">
			<br><p style="font-size:30px;">프로필 수정</p>
            <hr>
        </div>
		<div>
			<p>프로필 사진을 변경하고 새로고침을 누르세요.</p>
			<img src="./img/<?php echo $imgname ?>"
				onerror="this.src='./img/profileimg.jpg'" style="width:300px; height:300px">
			<form name="reqform" method="post" action="img2.php" enctype="multipart/form-data">
			<input type="file" name="imgFile" /><br><br>
			<span style="font-size:13px;">이미지 권장 비율 1:1</span>		
			<input type="submit" value="변경하기" style="margin-left:100px;">
			</form>
			
		</div>
	</div>
</body>