<!-- 게시글 검색 기능 -->

<?php 
session_start();

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

$search = $_GET['search'];
$category1=$_GET['category1'];
$profileimg=$_SESSION['nickname'];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search</title>
    <link rel="stylesheet" href="search.css">
</head>
<body>
    <br><br>
    <div class="main">
        <div>
            <button id="logo" onclick="location.href='blogmain2.php'"></button>
            <form method="get" action="search.php" style="display:inline;">
            <input type="text" value="<?=$search?>" id="search" name="search">
            <input type="submit" id="searchicon" value="" name="category1">  
            <input type="button" value="<?php echo "{$_SESSION['nickname']}"; ?>" id="profile">
            <img src="./img/<?php echo $profileimg ?>"
								onerror="this.src='./img/profileimg.jpg'" class="myimg">
        </div>
        <br>
        <hr>
      <input type="submit" id="category1" value="전체" name="category1"
      <?php if($category1==""||$category1=="전체"){?>
      style="background-color: lightcoral;"<?php }?>>  
      <input type="submit" id="category1" value="제목&내용" name="category1"
      <?php if($category1=="제목&내용"){?>
      style="background-color: lightcoral;"<?php }?>>  
      <input type="submit" id="category1" value="내용" name="category1"
      <?php if($category1=="내용"){?>
      style="background-color: lightcoral;"<?php }?>>  
      <input type="submit" id="category1" value="닉네임" name="category1"
      <?php if($category1=="닉네임"){?>
      style="background-color: lightcoral;"<?php }?>>  
      <input type="submit" id="category1" value="날짜" name="category1"
      <?php if($category1=="날짜"){?>
      style="background-color: lightcoral;"<?php }?>>  
      </form>
      <hr>
      <p><?=$search?> 의 검색결과</p>
        <!-- 검색 DB -->
        <?php
            mysqli_query($connect, "set session character_set_connection=utf8;");       
            mysqli_query($connect, "set session character_set_results=utf8;");
            mysqli_query($connect, "set session character_set_client=utf8;");   

            $sql = "select *from post ";                      // 테이블 검색 질의
            $result = mysqli_query ($connect, $sql);          // 질의 수행
            $total = mysqli_num_fields ($result);             // 필드의 개수 구하기
        ?>
        <table>
            <thead>
            <tr>
            <td width = "500">제목</td>
            <td width = "150">작성자</td>
            <td width = "250">날짜</td>
            <td width = "50">조회수</td>
            </tr>
            </thead>
    
            <tbody>
            <?php
                    while($rows = mysqli_fetch_assoc($result)){
					switch($category1){
					
                     case "전체": case "":
                     if(strchr($rows['CONTENT'], $search)||
					 strchr($rows['TITLE'], $search)||
					 strchr($rows['NICKNAME'], $search)||
					 strchr($rows['DATE'], $search)){
                     ?>
                     <tr>
                     <td>
                     <a href = "view.php?number=<?php echo $rows['NUM']?>">
                     <?php echo $rows['TITLE']?></td>
                     <td><?php echo $rows['NICKNAME']?></td>
                     <td><?php echo $rows['DATE']?></td>
                     <td><?php echo $rows['HIT']?></td>
                     </tr><?php break;}
                     case "제목&내용":
                        if(strchr($rows['TITLE'], $search)){
                     ?>
                     <tr>
                     <td>
                     <a href = "view.php?number=<?php echo $rows['NUM']?>">
                     <?php echo $rows['TITLE']?></td>
                     <td><?php echo $rows['NICKNAME']?></td>
                     <td><?php echo $rows['DATE']?></td>
                     <td><?php echo $rows['HIT']?></td>
                     </tr><?php break;} 
                     case "내용":
                        if(strchr($rows['CONTENT'], $search)){
                     ?>
                     <tr>
                     <td>
                     <a href = "view.php?number=<?php echo $rows['NUM']?>">
                     <?php echo $rows['TITLE']?></td>
                     <td><?php echo $rows['NICKNAME']?></td>
                     <td><?php echo $rows['DATE']?></td>
                     <td><?php echo $rows['HIT']?></td>
                     </tr><?php break;} 
                     case "닉네임":
                        if(strchr($rows['NICKNAME'], $search)){
                     ?>
                     <tr>
                     <td>
                     <a href = "view.php?number=<?php echo $rows['NUM']?>">
                     <?php echo $rows['TITLE']?></td>
                     <td><?php echo $rows['NICKNAME']?></td>
                     <td><?php echo $rows['DATE']?></td>
                     <td><?php echo $rows['HIT']?></td>
                     </tr><?php break;}
					 case "날짜":
                        if(strstr($rows['DATE'], $search)){
                     ?>
                     <tr>
                     <td>
                     <a href = "view.php?number=<?php echo $rows['NUM']?>">
                     <?php echo $rows['TITLE']?></td>
                     <td><?php echo $rows['NICKNAME']?></td>
                     <td><?php echo $rows['DATE']?></td>
                     <td><?php echo $rows['HIT']?></td>
                     </tr><?php break;}
                      ?>
            <?php
                    }
                }
            ?>
            </tbody>
      </table>
    </div>
</body>
</html>