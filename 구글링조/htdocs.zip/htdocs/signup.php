<?php
$connect = mysqli_connect ('localhost', 'root', '202130');   
mysqli_select_db ($connect, 'webblog');          // 질의 수행

$sql = "select *from minformation";                    
$result = mysqli_query ($connect, $sql);       
$total = mysqli_num_fields ($result);    

mysqli_query($connect, "set session character_set_connection=utf8;");       
mysqli_query($connect, "set session character_set_results=utf8;");       
mysqli_query($connect, "set session character_set_client=utf8;");   

if($_POST['id']&&$_POST['name']&&$_POST['nickname']&&$_POST['pw1']&&$_POST['pw2']
		&&$_POST['P1']&&$_POST['P2']&&$_POST['P3']&&$_POST['E1']){
			
	$count=0;
	$allcount=0;
	while($rows = mysqli_fetch_assoc($result)){
		$allcount++;
		if($_POST['id']==$rows['ID']){
			echo "<script>alert('이미 사용하는 아이디가 있습니다!');history.back();</script>";
			$count=0;
		}
		else{
			$count++;
		}
	}
	if($count>=$allcount){
		if($_POST['pw1']==$_POST['pw2']){
			echo "<script>alert('회원 가입이 완료되었습니다.')</script>";
			echo "<script>location.replace('login.html');</script>";
			
			$connect = mysqli_connect ('localhost', 'root', '202130');   
			mysqli_select_db ($connect, 'webblog'); 

			$sql = "INSERT INTO minformation(ID, NAME, NICKNAME , PW, PWh, PHONENUMBER, EMAIL)

			VALUES('{$_POST['id']}', '{$_POST['name']}', '{$_POST['nickname']}', '{$_POST['pw1']}', '{$_POST['pw2']}',
			'{$_POST['P1']}-{$_POST['P2']}-{$_POST['P3']}','{$_POST['E1']}')";
			
			mysqli_query($connect, $sql);
		}
		else{
			echo "<script>alert('비밀번호가 일치하지 않습니다.');history.back();</script>";
		}
	}
	else{
			echo "<script>history.back();</script>";
	}
}
else{
	echo "<script>alert('내용을 다 입력하세요!');history.back();</script>";
}
?>