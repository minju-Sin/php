<?php
session_start();
?>
<script>
		alert('로그아웃 완료!');
		location.replace('login.html');
		<?php 
			$destroy=true;
		?>
</script>