<?php
session_start();
$id = $_POST['id'];
$pw = $_POST['pw'];

$connect = mysqli_connect ('localhost', 'root', '202130');  
mysqli_select_db ($connect, 'webblog');

$check = "SELECT * FROM minformation WHERE ID = '$id'";
$result = $connect->query($check);

if($result->num_rows==1){
	$row = $result->fetch_array(MYSQLI_ASSOC);
	if($row['PW'] == $pw){
		$_SECCION['ID']=$id;
		if(isset($_SECCION['ID']))
		{
			$_SESSION['nickname']=$row['NICKNAME'];
			echo "<script>alert('{$row['NICKNAME']}님 환영합니다!')</script>";
			echo "<script>location.replace('blogmain2.php');</script>";
		}
		else{
			echo " 실패";
		}
	}
	else{
		echo "<script>alert('아이디나 비밀번호가 틀렸습니다.')</script>";
        echo "<script>location.replace('login.html');</script>";
        exit;
	}
}
else {
		echo "<script>alert('아이디나 비밀번호가 틀렸습니다.')</script>";
        echo "<script>location.replace('login.html');</script>";
        exit;
	
}
?>