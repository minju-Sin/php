<!-- 댓글 db 저장 -->
<?php
session_start();
   $connect = mysqli_connect ('localhost', 'root', '202130');   
   mysqli_select_db ($connect, 'webblog');          // 질의 수행

   /* ---------- 한글 깨짐 방지 코드 -----------------*/ 
   
   mysqli_query($connect, "set session character_set_connection=utf8;");       
   mysqli_query($connect, "set session character_set_results=utf8;");       
   mysqli_query($connect, "set session character_set_client=utf8;");   

   $content = $_POST['content'];
   $date = date('Y-m-d');	
   if($content){
       $sql = "INSERT INTO coment(NUM, NICKNAME, CONTENT, DATE, CHECKNUM)

           VALUES(0, '{$_SESSION['nickname']}', '{$_POST['content']}', '$date', '{$_SESSION['checknum']}' )";
       if (mysqli_query($connect, $sql)) {
           echo "<script>alert('댓글 작성에 성공하였습니다!')</script>";
           echo "<script>location.replace('view.php?number={$_SESSION['checknum']}');</script>";

       }
   }
   else{
       echo "<script>
       alert('댓글 작성에 실패했습니다.');
       history.back();</script>";
   }
?>

